#!/usr/bin/ruby

WALLPAPER_DIR = "/home/kyle/Pictures/Wallpapers/"
ALL_PICTURES = false
WIDTH = 1920
HEIGHT = 1200
SLEEP_TIME = 600 #This is numbers of seconds. So 600 is 10 minutes.

wallpapers = nil
Dir.chdir(WALLPAPER_DIR)
if(!ALL_PICTURES)
	wallpapers = Dir.glob("*#{WIDTH}x#{HEIGHT}*");
else
	wallpapers = Dir.glob("*");
end
while(true) do
    rand_wallpaper = wallpapers[wallpapers.length * rand]

    cmd = "gconftool-2 --type string --set /desktop/gnome/background/picture_filename \"#{File.join WALLPAPER_DIR, rand_wallpaper}\""
    puts cmd
    system cmd
    sleep(600)
end
