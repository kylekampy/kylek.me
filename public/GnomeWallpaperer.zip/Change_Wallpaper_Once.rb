#!/usr/bin/ruby

WALLPAPER_DIR = "/home/kyle/Pictures/Wallpapers/"
ALL_PICTURES = true
WIDTH = 1920
HEIGHT = 1200

Dir.chdir WALLPAPER_DIR
wallpapers = nil
if(!ALL_PICTURES)
	wallpapers = Dir.glob("*#{WIDTH}x#{HEIGHT}*");
else
	wallpapers = Dir.glob("*");
end
rand_wallpaper = wallpapers[wallpapers.length * rand]

cmd = "gconftool-2 --type string --set /desktop/gnome/background/picture_filename \"#{File.join WALLPAPER_DIR, rand_wallpaper}\""
puts cmd
system cmd
