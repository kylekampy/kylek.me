#!/usr/bin/ruby

#Make sure you have eyeD3 installed for this to work. Just run it from the directory you want to recurse through
#Issues: Won't process folders with '[' or ']' and won't process other non-standard characters.

def setArt(dir)
    files = Dir.glob "#{dir}/*"
    isAllFiles = true
        
    files.each do |cur|
        if File.directory? cur
            isAllFiles = false
            setArt cur
        end
    end
    
    if isAllFiles
        #puts "Folder #{dir} has no contained sub-directories"
        if File.exists? "#{dir}/cover.jpg"
            files = Dir.glob "#{dir}/*.mp3" #Only look at .mp3 files. Stay safe...
            puts "--Processing album \"#{File.basename dir}\"..."
            files.each do |curSong|
                #puts "Adding art to \"#{File.basename curSong}\"..."
                IO::popen('bash', 'r+') do |pipe|
                    pipe.puts "eyeD3 --remove-images \"#{curSong}\" 2>&1"
                    pipe.puts "eyeD3 --add-image=\"#{dir}/cover.jpg\":FRONT_COVER \"#{curSong}\" 2>&1"
                    pipe.puts "exit"
                    pipe.close_write
                    while !pipe.eof?
                        pipe.readline #ignore it
                    end
                    pipe.close
                end
            end
        else
            $stderr.puts "ERROR: No cover.jpg found for \"#{File.basename dir}\""
        end
    end
end


directory = ARGV.shift

if(directory == nil)
    directory = Dir.pwd #just run from here if we want to
else
    directory = File.expand_path directory
end

puts "Directory to scan is #{directory}\nStarting to scan..."

Dir.chdir(directory)
setArt(directory)

puts "Done processing #{directory}"
printf "Press enter to exit."
gets
exit 0
